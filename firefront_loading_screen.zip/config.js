
// Замінити "YOUR_API_KEY" у script.js на свій Steam API ключ
const staffMembers = [
    { steamid: "76561199074214536", role: "Управляючий" },
    // Додай свої SteamID та ролі тут
];
